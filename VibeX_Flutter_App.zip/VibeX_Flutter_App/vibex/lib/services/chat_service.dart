import 'dart:io';
import '../core/supa.dart';

class ChatService {
  /// Get-or-create the 1:1 chat with [otherId]. Ids are stored sorted so (a,b) == (b,a).
  static Future<String> openChat(String otherId) async {
    final ids = [myId, otherId]..sort();
    final existing = await sb
        .from('chats')
        .select('id')
        .eq('user_a', ids[0])
        .eq('user_b', ids[1])
        .maybeSingle();
    if (existing != null) return existing['id'];
    try {
      final c = await sb.from('chats').insert({'user_a': ids[0], 'user_b': ids[1]}).select('id').single();
      return c['id'];
    } catch (_) {
      final again = await sb.from('chats').select('id').eq('user_a', ids[0]).eq('user_b', ids[1]).single();
      return again['id'];
    }
  }

  static Stream<List<Map<String, dynamic>>> messages(String chatId) => sb
      .from('messages')
      .stream(primaryKey: ['id'])
      .eq('chat_id', chatId)
      .order('created_at', ascending: false);

  static Future<void> sendText(String chatId, String text) => sb.from('messages').insert({
        'chat_id': chatId,
        'sender_id': myId,
        'type': 'text',
        'body': text,
      });

  static Future<void> sendMedia(String chatId, File file, String type, {int? durationMs}) async {
    final ext = type == 'voice' ? 'm4a' : 'jpg';
    final path = '$chatId/${DateTime.now().millisecondsSinceEpoch}.$ext';
    await sb.storage.from('chat-media').upload(path, file);
    final url = sb.storage.from('chat-media').getPublicUrl(path);
    await sb.from('messages').insert({
      'chat_id': chatId,
      'sender_id': myId,
      'type': type,
      'media_url': url,
      'duration_ms': durationMs,
    });
  }
}
