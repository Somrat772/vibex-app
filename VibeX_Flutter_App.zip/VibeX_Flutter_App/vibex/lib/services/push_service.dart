import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_callkit_incoming/flutter_callkit_incoming.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import '../core/supa.dart';
import 'call_service.dart';

/// Runs in a background isolate when a push arrives and the app is closed/in background.
@pragma('vm:entry-point')
Future<void> firebaseBackgroundHandler(RemoteMessage m) async {
  await Firebase.initializeApp();
  if (m.data['type'] == 'call') {
    await CallUi.showIncoming(Map<String, dynamic>.from(m.data));
  }
  // Other pushes carry a `notification` payload and are shown by the OS automatically.
}

class PushService {
  static final _local = FlutterLocalNotificationsPlugin();
  static const _channel = AndroidNotificationChannel(
    'vibex_default',
    'VibeX notifications',
    importance: Importance.high,
  );

  static Future<void> init() async {
    await _local.initialize(const InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS: DarwinInitializationSettings(),
    ));
    await _local
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(_channel);

    // App in foreground: FCM does not show a banner by itself, so we do.
    FirebaseMessaging.onMessage.listen((m) {
      if (m.data['type'] == 'call') return; // handled via Realtime + CallUi
      final n = m.notification;
      if (n == null) return;
      _local.show(
        m.hashCode,
        n.title,
        n.body,
        NotificationDetails(
          android: AndroidNotificationDetails(_channel.id, _channel.name,
              importance: Importance.high, priority: Priority.high),
          iOS: const DarwinNotificationDetails(),
        ),
      );
    });

    FirebaseMessaging.instance.onTokenRefresh.listen(_saveToken);
  }

  /// Call after every successful login.
  static Future<void> onLogin() async {
    try {
      await FirebaseMessaging.instance.requestPermission(alert: true, badge: true, sound: true);
      await _local
          .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
          ?.requestNotificationsPermission();
    } catch (_) {}
    try {
      await FlutterCallkitIncoming.requestNotificationPermission({
        'title': 'Notification permission',
        'rationaleMessagePermission': 'VibeX needs notifications to show incoming calls.',
        'postNotificationMessageRequired': 'Please allow notifications in Settings to receive calls.',
      });
      await FlutterCallkitIncoming.requestFullIntentPermission();
    } catch (_) {}
    final t = await FirebaseMessaging.instance.getToken();
    if (t != null) await _saveToken(t);
  }

  static Future<void> _saveToken(String token) async {
    if (sb.auth.currentUser == null) return;
    await sb.from('device_tokens').upsert({'user_id': myId, 'token': token});
  }

  /// Call right before signing out so the device stops receiving this user's pushes.
  static Future<void> onLogout() async {
    try {
      await sb.from('device_tokens').delete().eq('user_id', myId);
    } catch (_) {}
  }
}
