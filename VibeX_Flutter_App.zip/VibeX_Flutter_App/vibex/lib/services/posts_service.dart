import 'package:share_plus/share_plus.dart';
import '../core/supa.dart';

const _select =
    '*, author:profiles!author_id(id, username, full_name, avatar_url, badge), post_likes(user_id)';

/// Fetch posts newest-first. [type] = 'text' | 'image' | 'reel'.
Future<List<Map<String, dynamic>>> fetchPosts({
  String? type,
  String? authorId,
  int from = 0,
  int to = 14,
}) async {
  var q = sb.from('posts').select(_select).eq('post_likes.user_id', myId);
  if (type != null) q = q.eq('type', type);
  if (authorId != null) q = q.eq('author_id', authorId);
  final rows = await q.order('created_at', ascending: false).range(from, to);
  return List<Map<String, dynamic>>.from(rows);
}

Future<Map<String, dynamic>?> fetchPost(String id) async {
  final r = await sb
      .from('posts')
      .select(_select)
      .eq('post_likes.user_id', myId)
      .eq('id', id)
      .maybeSingle();
  return r == null ? null : Map<String, dynamic>.from(r);
}

bool postLikedByMe(Map<String, dynamic> p) => (p['post_likes'] as List? ?? []).isNotEmpty;

Future<void> setLike(String postId, bool like) async {
  if (like) {
    await sb.from('post_likes').insert({'post_id': postId, 'user_id': myId});
  } else {
    await sb.from('post_likes').delete().match({'post_id': postId, 'user_id': myId});
  }
}

Future<void> sharePost(Map<String, dynamic> post) async {
  final who = post['author']?['username'] ?? 'someone';
  final text = post['body'] ?? '';
  await Share.share('Check out @$who on VibeX: $text ${post['media_url'] ?? ''}'.trim());
  await sb.rpc('bump_share', params: {'p_post': post['id']});
}
