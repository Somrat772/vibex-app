import 'dart:async';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'supa.dart';
import '../features/admin/admin_page.dart';
import '../features/auth/login_page.dart';
import '../features/auth/otp_page.dart';
import '../features/call/call_page.dart';
import '../features/chat/chat_page.dart';
import '../features/feed/create_post_page.dart';
import '../features/feed/post_view_page.dart';
import '../features/home/home_shell.dart';
import '../features/notifications/notifications_page.dart';
import '../features/premium/congrats_page.dart';
import '../features/premium/premium_page.dart';
import '../features/profile/profile_form_page.dart';
import '../features/profile/profile_page.dart';
import '../features/search/search_page.dart';

bool? _setupDone;
String? _setupUser;

/// Call after the setup form is saved so the router lets the user in.
void setupFinished() => _setupDone = true;

class _AuthRefresh extends ChangeNotifier {
  late final StreamSubscription _s;
  _AuthRefresh() {
    _s = sb.auth.onAuthStateChange.listen((_) => notifyListeners());
  }
  @override
  void dispose() {
    _s.cancel();
    super.dispose();
  }
}

final appRouter = GoRouter(
  refreshListenable: _AuthRefresh(),
  redirect: (context, state) async {
    final s = sb.auth.currentSession;
    final loc = state.matchedLocation;
    final isAuthPage = loc == '/login' || loc == '/otp';
    if (s == null) {
      _setupDone = null;
      _setupUser = null;
      return isAuthPage ? null : '/login';
    }
    if (_setupUser != s.user.id) {
      _setupUser = s.user.id;
      _setupDone = null;
    }
    _setupDone ??=
        (await sb.from('profiles').select('setup_complete').eq('id', s.user.id).single())['setup_complete'] == true;
    if (_setupDone != true) return loc == '/setup' ? null : '/setup';
    if (isAuthPage || loc == '/setup') return '/';
    return null;
  },
  routes: [
    GoRoute(path: '/login', builder: (_, __) => const LoginPage()),
    GoRoute(path: '/otp', builder: (_, s) => OtpPage(phone: s.extra as String)),
    GoRoute(path: '/setup', builder: (_, __) => const ProfileFormPage(isSetup: true)),
    GoRoute(path: '/edit-profile', builder: (_, __) => const ProfileFormPage(isSetup: false)),
    GoRoute(path: '/', builder: (_, __) => const HomeShell()),
    GoRoute(path: '/create', builder: (_, __) => const CreatePostPage()),
    GoRoute(path: '/search', builder: (_, __) => const SearchPage()),
    GoRoute(path: '/notifications', builder: (_, __) => const NotificationsPage()),
    GoRoute(path: '/premium', builder: (_, __) => const PremiumPage()),
    GoRoute(path: '/admin', builder: (_, __) => const AdminPage()),
    GoRoute(
        path: '/congrats',
        builder: (_, s) {
          final e = s.extra as Map<String, dynamic>;
          return CongratsPage(plan: e['plan'], expiresAt: e['expires_at']);
        }),
    GoRoute(path: '/profile/:id', builder: (_, s) => ProfilePage(userId: s.pathParameters['id']!)),
    GoRoute(path: '/post/:id', builder: (_, s) => PostViewPage(postId: s.pathParameters['id']!)),
    GoRoute(
        path: '/chat/:id',
        builder: (_, s) => ChatPage(chatId: s.pathParameters['id']!, peer: s.extra as Map<String, dynamic>)),
    GoRoute(
        path: '/call',
        builder: (_, s) {
          final e = s.extra as Map<String, dynamic>;
          return CallPage(
            callId: e['callId'],
            channel: e['channel'],
            video: e['video'],
            peerName: e['peerName'],
            peerAvatar: e['peerAvatar'],
            isCaller: e['isCaller'],
          );
        }),
  ],
);
