class Config {
  // Pass with: flutter run --dart-define=SUPABASE_URL=... (or edit the defaults below)
  static const supabaseUrl =
      String.fromEnvironment('SUPABASE_URL', defaultValue: 'https://bttxqzorygqaikmiagcp.supabase.co');
  static const supabaseAnonKey =
      String.fromEnvironment('SUPABASE_ANON_KEY', defaultValue: 'sb_publishable_1jnEc6mZobUIHI_luLpSyw_Pwg6VXAW');
  static const agoraAppId =
      String.fromEnvironment('AGORA_APP_ID', defaultValue: 'YOUR_AGORA_APP_ID');

  // Admin WhatsApp (01607040609 in international format)
  static const adminWhatsApp = '8801607040609';
}
