import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:video_player/video_player.dart';
import '../../services/posts_service.dart';
import '../../widgets/common.dart';
import 'comments_sheet.dart';

class ReelsPage extends StatefulWidget {
  final bool active;
  const ReelsPage({super.key, required this.active});
  @override
  State<ReelsPage> createState() => _ReelsPageState();
}

class _ReelsPageState extends State<ReelsPage> {
  final _reels = <Map<String, dynamic>>[];
  int _idx = 0;
  bool _loading = false, _done = false, _first = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (_loading || _done) return;
    _loading = true;
    try {
      final rows = await fetchPosts(type: 'reel', from: _reels.length, to: _reels.length + 9);
      if (rows.length < 10) _done = true;
      _reels.addAll(rows);
    } catch (_) {}
    _loading = false;
    if (mounted) setState(() => _first = false);
  }

  @override
  Widget build(BuildContext context) {
    if (_first) return const Center(child: CircularProgressIndicator());
    if (_reels.isEmpty) return const Center(child: Text('No reels yet. Upload the first one!'));
    return PageView.builder(
      scrollDirection: Axis.vertical,
      itemCount: _reels.length,
      onPageChanged: (i) {
        setState(() => _idx = i);
        if (i >= _reels.length - 3) _load();
      },
      itemBuilder: (_, i) =>
          ReelItem(key: ValueKey(_reels[i]['id']), reel: _reels[i], play: widget.active && i == _idx),
    );
  }
}

class ReelItem extends StatefulWidget {
  final Map<String, dynamic> reel;
  final bool play;
  const ReelItem({super.key, required this.reel, required this.play});
  @override
  State<ReelItem> createState() => _ReelItemState();
}

class _ReelItemState extends State<ReelItem> {
  late final VideoPlayerController _c;
  late bool _liked = postLikedByMe(widget.reel);
  late int _likes = widget.reel['like_count'] ?? 0;
  late int _comments = widget.reel['comment_count'] ?? 0;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _c = VideoPlayerController.networkUrl(Uri.parse(widget.reel['media_url']))
      ..setLooping(true)
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() => _ready = true);
        if (widget.play) _c.play();
      });
  }

  @override
  void didUpdateWidget(ReelItem old) {
    super.didUpdateWidget(old);
    if (widget.play != old.play && _ready) {
      widget.play ? _c.play() : _c.pause();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _like() async {
    final next = !_liked;
    setState(() {
      _liked = next;
      _likes += next ? 1 : -1;
    });
    try {
      await setLike(widget.reel['id'], next);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final a = widget.reel['author'] as Map?;
    return GestureDetector(
      onTap: () => setState(() => _c.value.isPlaying ? _c.pause() : _c.play()),
      child: Stack(fit: StackFit.expand, children: [
        const ColoredBox(color: Colors.black),
        if (_ready)
          FittedBox(
            fit: BoxFit.cover,
            child: SizedBox(width: _c.value.size.width, height: _c.value.size.height, child: VideoPlayer(_c)),
          )
        else
          const Center(child: CircularProgressIndicator()),
        if (_ready && !_c.value.isPlaying) const Center(child: Icon(Icons.play_arrow, size: 80, color: Colors.white54)),
        const Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            height: 220,
            child: DecoratedBox(
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [Colors.black87, Colors.transparent])))),
        Positioned(
          left: 14,
          right: 80,
          bottom: 20,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            GestureDetector(
              onTap: () => context.push('/profile/${a?['id']}'),
              child: Row(children: [
                Avatar(url: a?['avatar_url'], radius: 18),
                const SizedBox(width: 8),
                Flexible(child: NameRow(a, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
              ]),
            ),
            if ((widget.reel['body'] ?? '').toString().isNotEmpty)
              Padding(padding: const EdgeInsets.only(top: 8), child: Text(widget.reel['body'], maxLines: 3, overflow: TextOverflow.ellipsis)),
          ]),
        ),
        Positioned(
          right: 8,
          bottom: 30,
          child: Column(children: [
            IconButton(
                iconSize: 34,
                icon: Icon(_liked ? Icons.favorite : Icons.favorite_border, color: _liked ? Colors.redAccent : Colors.white),
                onPressed: _like),
            Text('$_likes'),
            const SizedBox(height: 14),
            IconButton(
                iconSize: 32,
                icon: const Icon(Icons.chat_bubble_outline),
                onPressed: () =>
                    showCommentsSheet(context, widget.reel['id'], onAdded: () => setState(() => _comments++))),
            Text('$_comments'),
            const SizedBox(height: 14),
            IconButton(iconSize: 32, icon: const Icon(Icons.share_outlined), onPressed: () => sharePost(widget.reel)),
            Text('${widget.reel['share_count'] ?? 0}'),
          ]),
        ),
      ]),
    );
  }
}
