import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../../core/supa.dart';
import '../../services/posts_service.dart';
import '../../widgets/common.dart';
import 'comments_sheet.dart';
import 'inline_video.dart';

class PostCard extends StatefulWidget {
  final Map<String, dynamic> post;
  final VoidCallback? onDeleted;
  const PostCard({super.key, required this.post, this.onDeleted});
  @override
  State<PostCard> createState() => _PostCardState();
}

class _PostCardState extends State<PostCard> {
  late bool _liked = postLikedByMe(widget.post);
  late int _likes = widget.post['like_count'] ?? 0;
  late int _comments = widget.post['comment_count'] ?? 0;
  late int _shares = widget.post['share_count'] ?? 0;

  Future<void> _toggleLike() async {
    final next = !_liked;
    setState(() {
      _liked = next;
      _likes += next ? 1 : -1;
    });
    try {
      await setLike(widget.post['id'], next);
    } catch (_) {
      if (mounted) {
        setState(() {
          _liked = !next;
          _likes += next ? -1 : 1;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.post;
    final a = p['author'] as Map?;
    final mine = a?['id'] == myId;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      color: const Color(0xFF0B1022),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        ListTile(
          leading: GestureDetector(
              onTap: () => context.push('/profile/${a?['id']}'), child: Avatar(url: a?['avatar_url'])),
          title: NameRow(a),
          subtitle: Text(timeago.format(DateTime.parse(p['created_at']).toLocal()),
              style: const TextStyle(fontSize: 12)),
          trailing: mine
              ? PopupMenuButton<String>(
                  onSelected: (_) async {
                    await sb.from('posts').delete().eq('id', p['id']);
                    widget.onDeleted?.call();
                  },
                  itemBuilder: (_) => const [PopupMenuItem(value: 'del', child: Text('Delete post'))],
                )
              : null,
        ),
        if ((p['body'] ?? '').toString().isNotEmpty)
          Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 10), child: Text(p['body'])),
        if (p['type'] == 'image' && p['media_url'] != null)
          CachedNetworkImage(
            imageUrl: p['media_url'],
            width: double.infinity,
            fit: BoxFit.cover,
            placeholder: (_, __) => const AspectRatio(aspectRatio: 1, child: Center(child: CircularProgressIndicator())),
          ),
        if (p['type'] == 'reel' && p['media_url'] != null) InlineVideo(url: p['media_url']),
        Row(children: [
          IconButton(
              icon: Icon(_liked ? Icons.favorite : Icons.favorite_border,
                  color: _liked ? Colors.redAccent : null),
              onPressed: _toggleLike),
          Text('$_likes'),
          IconButton(
              icon: const Icon(Icons.chat_bubble_outline),
              onPressed: () => showCommentsSheet(context, p['id'], onAdded: () => setState(() => _comments++))),
          Text('$_comments'),
          IconButton(
              icon: const Icon(Icons.share_outlined),
              onPressed: () async {
                await sharePost(p);
                if (mounted) setState(() => _shares++);
              }),
          Text('$_shares'),
        ]),
      ]),
    );
  }
}
