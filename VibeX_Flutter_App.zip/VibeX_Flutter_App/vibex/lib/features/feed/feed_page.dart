import 'package:flutter/material.dart';
import '../../services/posts_service.dart';
import 'post_card.dart';

class FeedPage extends StatefulWidget {
  const FeedPage({super.key});
  @override
  State<FeedPage> createState() => _FeedPageState();
}

class _FeedPageState extends State<FeedPage> {
  final _posts = <Map<String, dynamic>>[];
  final _scroll = ScrollController();
  bool _loading = false, _done = false, _firstLoad = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
    _scroll.addListener(() {
      if (_scroll.position.pixels > _scroll.position.maxScrollExtent - 700) _load();
    });
  }

  Future<void> _refresh() async {
    _posts.clear();
    _done = false;
    await _load();
  }

  Future<void> _load() async {
    if (_loading || _done) return;
    setState(() => _loading = true);
    try {
      final rows = await fetchPosts(from: _posts.length, to: _posts.length + 14);
      if (rows.length < 15) _done = true;
      _posts.addAll(rows);
      _error = null;
    } catch (e) {
      _error = '$e';
    }
    if (mounted) {
      setState(() {
        _loading = false;
        _firstLoad = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_firstLoad) return const Center(child: CircularProgressIndicator());
    if (_posts.isEmpty) {
      return RefreshIndicator(
        onRefresh: _refresh,
        child: ListView(children: [
          const SizedBox(height: 160),
          Center(child: Text(_error ?? 'No posts yet. Tap + to create the first one!')),
        ]),
      );
    }
    return RefreshIndicator(
      onRefresh: _refresh,
      child: ListView.builder(
        controller: _scroll,
        itemCount: _posts.length + (_loading ? 1 : 0),
        itemBuilder: (_, i) {
          if (i >= _posts.length) {
            return const Padding(padding: EdgeInsets.all(20), child: Center(child: CircularProgressIndicator()));
          }
          final p = _posts[i];
          return PostCard(
              key: ValueKey(p['id']), post: p, onDeleted: () => setState(() => _posts.removeWhere((x) => x['id'] == p['id'])));
        },
      ),
    );
  }
}
