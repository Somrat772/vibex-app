import 'dart:io';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../core/supa.dart';
import '../../models/plans.dart';
import '../../widgets/common.dart';

class CreatePostPage extends StatefulWidget {
  const CreatePostPage({super.key});
  @override
  State<CreatePostPage> createState() => _CreatePostPageState();
}

class _CreatePostPageState extends State<CreatePostPage> {
  final _body = TextEditingController();
  String _type = 'text'; // text | image | reel
  File? _file;
  bool _busy = false, _premium = false;

  @override
  void initState() {
    super.initState();
    sb.from('profiles').select('plan, premium_expires_at').eq('id', myId).single().then((p) {
      if (mounted) setState(() => _premium = isPremium(p));
    });
  }

  Future<void> _pickMedia() async {
    final picker = ImagePicker();
    XFile? x;
    if (_type == 'image') {
      x = await picker.pickImage(source: ImageSource.gallery, maxWidth: 1600, imageQuality: 85);
    } else {
      x = await picker.pickVideo(
          source: ImageSource.gallery,
          maxDuration: _premium ? const Duration(minutes: 5) : const Duration(seconds: 60));
    }
    if (x != null) setState(() => _file = File(x!.path));
  }

  Future<void> _post() async {
    if (_type == 'text' && _body.text.trim().isEmpty) return toast(context, 'Write something first');
    if (_type != 'text' && _file == null) return toast(context, 'Choose a ${_type == 'image' ? 'photo' : 'video'}');
    setState(() => _busy = true);
    try {
      String? url;
      if (_file != null) {
        final bucket = _type == 'reel' ? 'reels' : 'posts';
        final ext = _type == 'reel' ? 'mp4' : 'jpg';
        final path = '$myId/${DateTime.now().millisecondsSinceEpoch}.$ext';
        await sb.storage.from(bucket).upload(path, _file!,
            fileOptions: FileOptions(contentType: _type == 'reel' ? 'video/mp4' : 'image/jpeg'));
        url = sb.storage.from(bucket).getPublicUrl(path);
      }
      await sb.from('posts').insert({
        'author_id': myId,
        'type': _type,
        'body': _body.text.trim(),
        'media_url': url,
      });
      if (mounted) {
        toast(context, 'Posted!');
        context.pop();
      }
    } on PostgrestException catch (e) {
      if (!mounted) return;
      if (e.message.contains('FREE_LIMIT')) {
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('Daily limit reached'),
            content: const Text('Free accounts can post 5 times per day. Go Premium for unlimited posts.'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context), child: const Text('Later')),
              FilledButton(
                  onPressed: () {
                    Navigator.pop(context);
                    context.push('/premium');
                  },
                  child: const Text('Get Premium')),
            ],
          ),
        );
      } else {
        toast(context, e.message);
      }
    } catch (e) {
      if (mounted) toast(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Create'), actions: [
          Padding(
              padding: const EdgeInsets.only(right: 12),
              child: GradientButton(label: _busy ? 'Posting...' : 'Post', onTap: _busy ? null : _post)),
        ]),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'text', icon: Icon(Icons.notes), label: Text('Text')),
              ButtonSegment(value: 'image', icon: Icon(Icons.image), label: Text('Photo')),
              ButtonSegment(value: 'reel', icon: Icon(Icons.videocam), label: Text('Reel')),
            ],
            selected: {_type},
            onSelectionChanged: (s) => setState(() {
              _type = s.first;
              _file = null;
            }),
          ),
          const SizedBox(height: 16),
          TextField(
              controller: _body,
              maxLines: 6,
              decoration: InputDecoration(hintText: _type == 'text' ? "What's on your mind?" : 'Write a caption...')),
          const SizedBox(height: 14),
          if (_type != 'text')
            OutlinedButton.icon(
              icon: Icon(_file == null ? Icons.add_photo_alternate : Icons.check_circle),
              label: Text(_file == null
                  ? (_type == 'image' ? 'Choose photo from gallery' : 'Choose video from gallery')
                  : 'Selected - tap to change'),
              onPressed: _pickMedia,
            ),
          if (_type == 'image' && _file != null)
            Padding(
                padding: const EdgeInsets.only(top: 12),
                child: ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.file(_file!))),
          if (_type == 'reel')
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Text(
                  _premium ? 'Premium: reels up to 5 minutes' : 'Free: reels up to 60 seconds (Premium: 5 minutes)',
                  style: const TextStyle(color: Colors.white54, fontSize: 12)),
            ),
        ]),
      );
}
