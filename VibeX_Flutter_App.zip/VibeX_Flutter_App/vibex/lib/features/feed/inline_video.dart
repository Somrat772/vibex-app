import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

/// Tap-to-play video used inside feed cards and post pages.
class InlineVideo extends StatefulWidget {
  final String url;
  const InlineVideo({super.key, required this.url});
  @override
  State<InlineVideo> createState() => _InlineVideoState();
}

class _InlineVideoState extends State<InlineVideo> {
  late final VideoPlayerController _c;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _c = VideoPlayerController.networkUrl(Uri.parse(widget.url))
      ..setLooping(true)
      ..initialize().then((_) {
        if (mounted) setState(() => _ready = true);
      });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_ready) {
      return const AspectRatio(aspectRatio: 9 / 12, child: Center(child: CircularProgressIndicator()));
    }
    return GestureDetector(
      onTap: () => setState(() => _c.value.isPlaying ? _c.pause() : _c.play()),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * .65),
        child: Stack(alignment: Alignment.center, children: [
          AspectRatio(aspectRatio: _c.value.aspectRatio, child: VideoPlayer(_c)),
          if (!_c.value.isPlaying) const Icon(Icons.play_circle_fill, size: 64, color: Colors.white70),
        ]),
      ),
    );
  }
}
