import 'package:flutter/material.dart';
import '../../services/posts_service.dart';
import 'post_card.dart';

class PostViewPage extends StatelessWidget {
  final String postId;
  const PostViewPage({super.key, required this.postId});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Post')),
        body: FutureBuilder<Map<String, dynamic>?>(
          future: fetchPost(postId),
          builder: (c, s) {
            if (s.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
            if (s.data == null) return const Center(child: Text('This post is no longer available'));
            return ListView(children: [PostCard(post: s.data!, onDeleted: () => Navigator.pop(context))]);
          },
        ),
      );
}
