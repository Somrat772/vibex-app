import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../../core/supa.dart';
import '../../widgets/common.dart';

class ChatListPage extends StatelessWidget {
  const ChatListPage({super.key});

  @override
  Widget build(BuildContext context) => StreamBuilder<List<Map<String, dynamic>>>(
        // RLS returns only chats the current user belongs to
        stream: sb.from('chats').stream(primaryKey: ['id']).order('updated_at', ascending: false),
        builder: (c, s) {
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          final chats = s.data!;
          if (chats.isEmpty) {
            return Center(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Text('No conversations yet'),
                const SizedBox(height: 10),
                FilledButton(onPressed: () => context.push('/search'), child: const Text('Find people')),
              ]),
            );
          }
          return ListView.builder(
            itemCount: chats.length,
            itemBuilder: (_, i) => _ChatTile(chat: chats[i]),
          );
        },
      );
}

class _ChatTile extends StatefulWidget {
  final Map<String, dynamic> chat;
  const _ChatTile({required this.chat});
  @override
  State<_ChatTile> createState() => _ChatTileState();
}

class _ChatTileState extends State<_ChatTile> {
  late final Future<Map<String, dynamic>> _peer = sb
      .from('profiles')
      .select('id, username, full_name, avatar_url, badge')
      .eq('id', widget.chat['user_a'] == myId ? widget.chat['user_b'] : widget.chat['user_a'])
      .single();

  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>>(
        future: _peer,
        builder: (c, s) {
          final p = s.data;
          if (p == null) return const SizedBox(height: 72);
          return ListTile(
            leading: Avatar(url: p['avatar_url'], radius: 24),
            title: NameRow(p, useFullName: true),
            subtitle: Text(widget.chat['last_message'] ?? 'Say hi', maxLines: 1, overflow: TextOverflow.ellipsis),
            trailing: Text(timeago.format(DateTime.parse(widget.chat['updated_at']).toLocal(), locale: 'en_short'),
                style: const TextStyle(fontSize: 11, color: Colors.white38)),
            onTap: () => context.push('/chat/${widget.chat['id']}', extra: p),
          );
        },
      );
}
