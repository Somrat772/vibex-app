import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import '../../core/supa.dart';
import '../../core/theme.dart';
import '../../services/call_service.dart';
import '../../services/chat_service.dart';
import '../../widgets/common.dart';

class ChatPage extends StatefulWidget {
  final String chatId;
  final Map<String, dynamic> peer;
  const ChatPage({super.key, required this.chatId, required this.peer});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final _ctrl = TextEditingController();
  final _rec = AudioRecorder();
  bool _recording = false;
  DateTime? _recStart;

  @override
  void dispose() {
    _rec.dispose();
    super.dispose();
  }

  Future<void> _sendText() async {
    final t = _ctrl.text.trim();
    if (t.isEmpty) return;
    _ctrl.clear();
    try {
      await ChatService.sendText(widget.chatId, t);
    } catch (e) {
      if (mounted) toast(context, 'Could not send: $e');
    }
  }

  Future<void> _sendImage() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1600, imageQuality: 85);
    if (x == null) return;
    try {
      await ChatService.sendMedia(widget.chatId, File(x.path), 'image');
    } catch (e) {
      if (mounted) toast(context, 'Could not send image: $e');
    }
  }

  Future<void> _startRec() async {
    if (!await _rec.hasPermission()) {
      if (mounted) toast(context, 'Microphone permission is required for voice notes');
      return;
    }
    final dir = await getTemporaryDirectory();
    await _rec.start(const RecordConfig(encoder: AudioEncoder.aacLc),
        path: '${dir.path}/vn_${DateTime.now().millisecondsSinceEpoch}.m4a');
    setState(() {
      _recording = true;
      _recStart = DateTime.now();
    });
  }

  Future<void> _stopRec() async {
    if (!_recording) return;
    final path = await _rec.stop();
    final ms = DateTime.now().difference(_recStart!).inMilliseconds;
    setState(() => _recording = false);
    if (path == null || ms < 700) return; // ignore accidental taps
    try {
      await ChatService.sendMedia(widget.chatId, File(path), 'voice', durationMs: ms);
    } catch (e) {
      if (mounted) toast(context, 'Could not send voice note: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final peer = widget.peer;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: GestureDetector(
          onTap: () => context.push('/profile/${peer['id']}'),
          child: Row(children: [
            Avatar(url: peer['avatar_url'], radius: 18),
            const SizedBox(width: 10),
            Flexible(child: NameRow(peer, useFullName: true)),
          ]),
        ),
        actions: [
          IconButton(icon: const Icon(Icons.call), onPressed: () => startCall(context, peer, video: false)),
          IconButton(icon: const Icon(Icons.videocam), onPressed: () => startCall(context, peer, video: true)),
        ],
      ),
      body: Column(children: [
        Expanded(
          child: StreamBuilder<List<Map<String, dynamic>>>(
            stream: ChatService.messages(widget.chatId),
            builder: (c, s) {
              if (!s.hasData) return const Center(child: CircularProgressIndicator());
              final msgs = s.data!;
              if (msgs.isEmpty) return const Center(child: Text('No messages yet. Say hi!'));
              return ListView.builder(
                reverse: true,
                padding: const EdgeInsets.all(12),
                itemCount: msgs.length,
                itemBuilder: (_, i) => _Bubble(m: msgs[i]),
              );
            },
          ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(8, 6, 8, 8),
            child: Row(children: [
              IconButton(icon: const Icon(Icons.image_outlined), onPressed: _sendImage),
              Expanded(
                child: _recording
                    ? const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                        child: Row(children: [
                          Icon(Icons.fiber_manual_record, color: Colors.redAccent, size: 16),
                          SizedBox(width: 8),
                          Text('Recording... release to send'),
                        ]))
                    : TextField(
                        controller: _ctrl,
                        minLines: 1,
                        maxLines: 4,
                        onChanged: (_) => setState(() {}),
                        decoration: const InputDecoration(hintText: 'Message...'),
                      ),
              ),
              const SizedBox(width: 6),
              if (_ctrl.text.trim().isNotEmpty && !_recording)
                IconButton.filled(icon: const Icon(Icons.send), onPressed: _sendText)
              else
                GestureDetector(
                  onLongPressStart: (_) => _startRec(),
                  onLongPressEnd: (_) => _stopRec(),
                  child: CircleAvatar(
                    radius: 22,
                    backgroundColor: _recording ? Colors.redAccent : VX.blue,
                    child: const Icon(Icons.mic),
                  ),
                ),
            ]),
          ),
        ),
      ]),
    );
  }
}

class _Bubble extends StatelessWidget {
  final Map<String, dynamic> m;
  const _Bubble({required this.m});

  @override
  Widget build(BuildContext context) {
    final mine = m['sender_id'] == myId;
    Widget content;
    switch (m['type']) {
      case 'image':
        content = ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: CachedNetworkImage(imageUrl: m['media_url'], width: 220, fit: BoxFit.cover),
        );
        break;
      case 'voice':
        content = VoiceBubble(url: m['media_url'], ms: m['duration_ms'] ?? 0);
        break;
      default:
        content = Text(m['body'] ?? '', style: const TextStyle(fontSize: 15));
    }
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 3),
        padding: m['type'] == 'image' ? const EdgeInsets.all(3) : const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .75),
        decoration: BoxDecoration(
          gradient: mine ? const LinearGradient(colors: [Color(0xFF2B7BD6), Color(0xFF8B3FD0)]) : null,
          color: mine ? null : VX.card,
          borderRadius: BorderRadius.circular(16),
        ),
        child: content,
      ),
    );
  }
}

class VoiceBubble extends StatefulWidget {
  final String url;
  final int ms;
  const VoiceBubble({super.key, required this.url, required this.ms});
  @override
  State<VoiceBubble> createState() => _VoiceBubbleState();
}

class _VoiceBubbleState extends State<VoiceBubble> {
  final _player = AudioPlayer();
  bool _loaded = false;

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  Future<void> _toggle() async {
    if (!_loaded) {
      await _player.setUrl(widget.url);
      _loaded = true;
    }
    if (_player.playing) {
      await _player.pause();
    } else {
      if (_player.processingState == ProcessingState.completed) await _player.seek(Duration.zero);
      _player.play();
    }
  }

  @override
  Widget build(BuildContext context) {
    final secs = (widget.ms / 1000).round();
    return StreamBuilder<PlayerState>(
      stream: _player.playerStateStream,
      builder: (c, s) {
        final playing = s.data?.playing == true && s.data?.processingState != ProcessingState.completed;
        return Row(mainAxisSize: MainAxisSize.min, children: [
          IconButton(
              visualDensity: VisualDensity.compact,
              icon: Icon(playing ? Icons.pause_circle_filled : Icons.play_circle_fill, size: 34),
              onPressed: _toggle),
          const Icon(Icons.graphic_eq),
          const SizedBox(width: 8),
          Text('0:${secs.toString().padLeft(2, '0')}'),
        ]);
      },
    );
  }
}
