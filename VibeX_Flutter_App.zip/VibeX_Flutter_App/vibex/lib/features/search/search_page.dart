import 'dart:async';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/supa.dart';
import '../../widgets/common.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});
  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final _ctrl = TextEditingController();
  Timer? _debounce;
  List<Map<String, dynamic>> _res = [];
  bool _loading = false;

  void _onChanged(String q) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), () => _search(q.trim()));
  }

  Future<void> _search(String q) async {
    if (q.isEmpty) return setState(() => _res = []);
    setState(() => _loading = true);
    final safe = q.replaceAll(RegExp(r'[%,()]'), '');
    final rows = await sb
        .from('profiles')
        .select('id, username, full_name, avatar_url, badge, bio')
        .eq('setup_complete', true)
        .or('username.ilike.%$safe%,full_name.ilike.%$safe%')
        .limit(30);
    if (mounted) {
      setState(() {
        _res = List<Map<String, dynamic>>.from(rows);
        _loading = false;
      });
    }
  }

  @override
  void dispose() {
    _debounce?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: TextField(
            controller: _ctrl,
            autofocus: true,
            onChanged: _onChanged,
            decoration: const InputDecoration(hintText: 'Search people...', prefixIcon: Icon(Icons.search)),
          ),
        ),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : ListView.builder(
                itemCount: _res.length,
                itemBuilder: (_, i) {
                  final u = _res[i];
                  return ListTile(
                    leading: Avatar(url: u['avatar_url']),
                    title: NameRow(u),
                    subtitle: Text(u['full_name'] ?? ''),
                    onTap: () => context.push('/profile/${u['id']}'),
                  );
                },
              ),
      );
}
