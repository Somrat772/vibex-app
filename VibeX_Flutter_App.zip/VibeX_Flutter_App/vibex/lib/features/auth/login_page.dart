import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../core/supa.dart';
import '../../widgets/common.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with SingleTickerProviderStateMixin {
  late final TabController _tab = TabController(length: 2, vsync: this);
  final _email = TextEditingController();
  final _pass = TextEditingController();
  final _phone = TextEditingController(text: '+880');
  bool _signUp = false, _busy = false;

  Future<void> _run(Future<void> Function() f) async {
    setState(() => _busy = true);
    try {
      await f();
    } on AuthException catch (e) {
      if (mounted) toast(context, e.message);
    } catch (e) {
      if (mounted) toast(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _emailAuth() => _run(() async {
        final email = _email.text.trim();
        if (email.isEmpty || _pass.text.length < 6) {
          toast(context, 'Enter a valid email and a password of 6+ characters');
          return;
        }
        if (_signUp) {
          final r = await sb.auth.signUp(email: email, password: _pass.text);
          if (r.session == null && mounted) {
            toast(context, 'Check your email to confirm your account, then sign in.');
            setState(() => _signUp = false);
          }
        } else {
          await sb.auth.signInWithPassword(email: email, password: _pass.text);
        }
      });

  Future<void> _sendOtp() => _run(() async {
        final phone = _phone.text.trim();
        if (!RegExp(r'^\+\d{10,15}$').hasMatch(phone)) {
          toast(context, 'Use international format, e.g. +8801XXXXXXXXX');
          return;
        }
        await sb.auth.signInWithOtp(phone: phone);
        if (mounted) context.push('/otp', extra: phone);
      });

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420),
                child: Column(children: [
                  ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: Image.asset('assets/logo.jpg', height: 170, fit: BoxFit.cover)),
                  const SizedBox(height: 20),
                  TabBar(controller: _tab, tabs: const [Tab(text: 'Email'), Tab(text: 'Phone')]),
                  const SizedBox(height: 16),
                  SizedBox(
                    height: 250,
                    child: TabBarView(controller: _tab, children: [
                      Column(children: [
                        TextField(
                            controller: _email,
                            keyboardType: TextInputType.emailAddress,
                            decoration: const InputDecoration(labelText: 'Email')),
                        const SizedBox(height: 12),
                        TextField(
                            controller: _pass,
                            obscureText: true,
                            decoration: const InputDecoration(labelText: 'Password')),
                        const SizedBox(height: 16),
                        SizedBox(
                            width: double.infinity,
                            child: GradientButton(
                                label: _busy ? 'Please wait...' : (_signUp ? 'Create account' : 'Sign in'),
                                onTap: _busy ? null : _emailAuth)),
                        TextButton(
                            onPressed: () => setState(() => _signUp = !_signUp),
                            child: Text(_signUp ? 'Already have an account? Sign in' : 'New here? Create account')),
                      ]),
                      Column(children: [
                        TextField(
                            controller: _phone,
                            keyboardType: TextInputType.phone,
                            decoration: const InputDecoration(labelText: 'Phone number (+880...)')),
                        const SizedBox(height: 16),
                        SizedBox(
                            width: double.infinity,
                            child: GradientButton(
                                label: _busy ? 'Sending...' : 'Send OTP', onTap: _busy ? null : _sendOtp)),
                        const SizedBox(height: 8),
                        const Text('New numbers create an account automatically.',
                            style: TextStyle(color: Colors.white54)),
                      ]),
                    ]),
                  ),
                ]),
              ),
            ),
          ),
        ),
      );
}
