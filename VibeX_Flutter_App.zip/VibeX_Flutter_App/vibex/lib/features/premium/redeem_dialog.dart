import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../core/supa.dart';

Future<void> showRedeemDialog(BuildContext context) async {
  final ctrl = TextEditingController();
  String? err;
  bool loading = false;

  await showDialog(
    context: context,
    barrierDismissible: false,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setS) => AlertDialog(
        title: const Text('Redeem Code'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(
            controller: ctrl,
            autofocus: true,
            textCapitalization: TextCapitalization.characters,
            decoration: const InputDecoration(hintText: 'Enter your code'),
          ),
          if (err != null)
            Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Text(err!, style: const TextStyle(color: Colors.redAccent))),
        ]),
        actions: [
          TextButton(onPressed: loading ? null : () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: loading
                ? null
                : () async {
                    final code = ctrl.text.trim();
                    if (code.isEmpty) return;
                    setS(() {
                      loading = true;
                      err = null;
                    });
                    try {
                      final res = Map<String, dynamic>.from(
                          await sb.rpc('redeem_code', params: {'p_code': code}) as Map);
                      if (res['ok'] == true) {
                        if (ctx.mounted) Navigator.pop(ctx);
                        if (context.mounted) await context.push('/congrats', extra: res);
                      } else {
                        setS(() {
                          loading = false;
                          err = res['error'] == 'too_many_attempts'
                              ? 'Too many wrong attempts. Try again in an hour.'
                              : 'Invalid or already used code.';
                        });
                      }
                    } catch (e) {
                      setS(() {
                        loading = false;
                        err = 'Something went wrong. Check your internet and try again.';
                      });
                    }
                  },
            child: Text(loading ? 'Checking...' : 'Redeem'),
          ),
        ],
      ),
    ),
  );
}
