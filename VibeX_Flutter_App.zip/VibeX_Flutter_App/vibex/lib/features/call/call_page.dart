import 'dart:async';
import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:flutter/material.dart';
import 'package:flutter_callkit_incoming/flutter_callkit_incoming.dart';
import 'package:go_router/go_router.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../core/config.dart';
import '../../core/supa.dart';
import '../../core/theme.dart';
import '../../widgets/common.dart';

class CallPage extends StatefulWidget {
  final String callId, channel, peerName;
  final String? peerAvatar;
  final bool video, isCaller;
  const CallPage({
    super.key,
    required this.callId,
    required this.channel,
    required this.peerName,
    required this.video,
    required this.isCaller,
    this.peerAvatar,
  });
  @override
  State<CallPage> createState() => _CallPageState();
}

class _CallPageState extends State<CallPage> {
  RtcEngine? _engine;
  int? _remote;
  bool _ready = false, _muted = false, _speaker = false, _camOff = false, _closing = false;
  int _secs = 0;
  Timer? _clock, _ringTimeout;
  StreamSubscription? _sub;
  String _status = 'Connecting...';

  @override
  void initState() {
    super.initState();
    _speaker = widget.video;
    _init();
  }

  Future<void> _init() async {
    final perms = await [Permission.microphone, if (widget.video) Permission.camera].request();
    if (perms.values.any((p) => !p.isGranted)) {
      if (mounted) toast(context, 'Microphone/camera permission is required for calls');
      return _end();
    }
    try {
      final res = await sb.functions.invoke('agora-token', body: {'channel': widget.channel});
      final token = (res.data as Map)['token'] as String;

      final e = createAgoraRtcEngine();
      _engine = e;
      await e.initialize(RtcEngineContext(
        appId: Config.agoraAppId,
        channelProfile: ChannelProfileType.channelProfileCommunication,
      ));
      e.registerEventHandler(RtcEngineEventHandler(
        onJoinChannelSuccess: (conn, elapsed) {
          if (mounted) setState(() => _status = widget.isCaller ? 'Ringing...' : 'Connecting...');
        },
        onUserJoined: (conn, uid, elapsed) {
          _ringTimeout?.cancel();
          _clock ??= Timer.periodic(const Duration(seconds: 1), (_) {
            if (mounted) setState(() => _secs++);
          });
          if (mounted) setState(() => _remote = uid);
        },
        onUserOffline: (conn, uid, reason) => _end(),
      ));
      await e.enableAudio();
      if (widget.video) {
        await e.enableVideo();
        await e.startPreview();
      }
      await e.setEnableSpeakerphone(_speaker);
      await e.joinChannel(
        token: token,
        channelId: widget.channel,
        uid: 0,
        options: ChannelMediaOptions(
          clientRoleType: ClientRoleType.clientRoleBroadcaster,
          channelProfile: ChannelProfileType.channelProfileCommunication,
          publishMicrophoneTrack: true,
          publishCameraTrack: widget.video,
          autoSubscribeAudio: true,
          autoSubscribeVideo: true,
        ),
      );
      if (mounted) setState(() => _ready = true);

      // End the screen when the other side rejects / hangs up.
      _sub = sb.from('calls').stream(primaryKey: ['id']).eq('id', widget.callId).listen((rows) {
        if (rows.isEmpty) return;
        final s = rows.first['status'];
        if (s == 'rejected' || s == 'missed' || s == 'ended') _end(updateDb: false);
      });

      if (widget.isCaller) {
        _ringTimeout = Timer(const Duration(seconds: 45), () async {
          if (_remote == null) {
            await sb.from('calls').update({'status': 'missed'}).eq('id', widget.callId).eq('status', 'ringing');
            if (mounted) toast(context, 'No answer');
            _end(updateDb: false);
          }
        });
      }
    } catch (e) {
      if (mounted) toast(context, 'Call failed: $e');
      _end();
    }
  }

  Future<void> _end({bool updateDb = true}) async {
    if (_closing) return;
    _closing = true;
    _clock?.cancel();
    _ringTimeout?.cancel();
    await _sub?.cancel();
    if (updateDb) {
      try {
        await sb
            .from('calls')
            .update({'status': 'ended'})
            .eq('id', widget.callId)
            .inFilter('status', ['ringing', 'accepted']);
      } catch (_) {}
    }
    try {
      await _engine?.leaveChannel();
      await _engine?.release();
    } catch (_) {}
    try {
      await FlutterCallkitIncoming.endCall(widget.callId);
    } catch (_) {}
    if (mounted) context.pop();
  }

  @override
  void dispose() {
    _clock?.cancel();
    _ringTimeout?.cancel();
    _sub?.cancel();
    if (!_closing) {
      _engine?.leaveChannel();
      _engine?.release();
    }
    super.dispose();
  }

  String get _timer {
    final m = (_secs ~/ 60).toString().padLeft(2, '0');
    final s = (_secs % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final e = _engine;
    final showRemoteVideo = widget.video && _remote != null && _ready && e != null;
    return PopScope(
      canPop: false,
      child: Scaffold(
        body: Stack(fit: StackFit.expand, children: [
          if (showRemoteVideo)
            AgoraVideoView(
              controller: VideoViewController.remote(
                rtcEngine: e,
                canvas: VideoCanvas(uid: _remote),
                connection: RtcConnection(channelId: widget.channel),
              ),
            )
          else
            Container(
              decoration: const BoxDecoration(
                  gradient: LinearGradient(
                      begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF0B1B3F), Color(0xFF3A1457)])),
              child: Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Avatar(url: widget.peerAvatar, radius: 64),
                  const SizedBox(height: 20),
                  Text(widget.peerName, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(_remote != null ? _timer : _status, style: const TextStyle(color: Colors.white70, fontSize: 16)),
                ]),
              ),
            ),
          if (showRemoteVideo)
            Positioned(
              top: 50,
              left: 0,
              right: 0,
              child: Center(
                  child: Text('${widget.peerName}  $_timer',
                      style: const TextStyle(fontSize: 16, shadows: [Shadow(blurRadius: 6)]))),
            ),
          if (widget.video && _ready && e != null && !_camOff)
            Positioned(
              top: 50,
              right: 16,
              width: 110,
              height: 160,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: AgoraVideoView(
                  controller: VideoViewController(rtcEngine: e, canvas: const VideoCanvas(uid: 0)),
                ),
              ),
            ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 40,
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              _btn(_muted ? Icons.mic_off : Icons.mic, _muted, () async {
                setState(() => _muted = !_muted);
                await e?.muteLocalAudioStream(_muted);
              }),
              _btn(_speaker ? Icons.volume_up : Icons.hearing, _speaker, () async {
                setState(() => _speaker = !_speaker);
                await e?.setEnableSpeakerphone(_speaker);
              }),
              if (widget.video) ...[
                _btn(_camOff ? Icons.videocam_off : Icons.videocam, _camOff, () async {
                  setState(() => _camOff = !_camOff);
                  await e?.muteLocalVideoStream(_camOff);
                }),
                _btn(Icons.cameraswitch, false, () => e?.switchCamera()),
              ],
              FloatingActionButton(
                backgroundColor: Colors.redAccent,
                onPressed: () => _end(),
                child: const Icon(Icons.call_end, color: Colors.white),
              ),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _btn(IconData icon, bool active, VoidCallback onTap) => CircleAvatar(
        radius: 26,
        backgroundColor: active ? Colors.white : Colors.white24,
        child: IconButton(icon: Icon(icon, color: active ? VX.bg : Colors.white), onPressed: onTap),
      );
}
