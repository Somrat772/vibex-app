import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'core/config.dart';
import 'core/router.dart';
import 'core/supa.dart';
import 'core/theme.dart';
import 'services/call_service.dart';
import 'services/push_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(); // uses google-services.json / GoogleService-Info.plist
  FirebaseMessaging.onBackgroundMessage(firebaseBackgroundHandler);
  // supabase_flutter stores the session locally and restores it on every launch,
  // so users stay logged in until they sign out.
  await Supabase.initialize(url: Config.supabaseUrl, anonKey: Config.supabaseAnonKey);
  await PushService.init();
  runApp(const VibeXApp());
}

class VibeXApp extends StatefulWidget {
  const VibeXApp({super.key});
  @override
  State<VibeXApp> createState() => _VibeXAppState();
}

class _VibeXAppState extends State<VibeXApp> {
  @override
  void initState() {
    super.initState();
    sb.auth.onAuthStateChange.listen((d) {
      if (d.session != null &&
          (d.event == AuthChangeEvent.signedIn || d.event == AuthChangeEvent.initialSession)) {
        _onLoggedIn();
      }
      if (d.event == AuthChangeEvent.signedOut) IncomingCallListener.stop();
    });
    if (sb.auth.currentSession != null) _onLoggedIn();
    FirebaseMessaging.onMessageOpenedApp.listen((m) {
      if (m.data['type'] != 'call') appRouter.push('/notifications');
    });
  }

  void _onLoggedIn() {
    PushService.onLogin();
    IncomingCallListener.start();
  }

  @override
  Widget build(BuildContext context) => MaterialApp.router(
        title: 'VibeX',
        debugShowCheckedModeBanner: false,
        theme: vibexTheme(),
        routerConfig: appRouter,
      );
}
