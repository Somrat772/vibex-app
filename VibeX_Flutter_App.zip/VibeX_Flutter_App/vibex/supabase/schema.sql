-- =====================================================================
-- VibeX - complete Supabase schema (run once in the SQL editor)
-- =====================================================================

-- PROFILES ------------------------------------------------------------
create table profiles (
  id uuid primary key references auth.users on delete cascade,
  username text unique check (username = lower(username)),
  full_name text,
  bio text default '',
  avatar_url text,
  cover_url text,
  is_verified boolean not null default false,
  badge text not null default 'none' check (badge in ('none','blue','gold')),
  plan text not null default 'free' check (plan in ('free','student','pro','promax')),
  premium_expires_at timestamptz,
  is_admin boolean not null default false,
  setup_complete boolean not null default false,
  created_at timestamptz default now()
);

-- Users can edit ONLY these columns. Premium/verified/admin columns are server-controlled.
revoke update on profiles from authenticated, anon;
grant update (username, full_name, bio, avatar_url, cover_url, setup_complete) on profiles to authenticated;

alter table profiles enable row level security;
create policy "profiles readable" on profiles for select using (true);
create policy "own profile update" on profiles for update using (auth.uid() = id);

create function handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id) values (new.id) on conflict do nothing;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

-- DEVICE TOKENS (FCM) - private to each user -------------------------
create table device_tokens (
  user_id uuid primary key references profiles on delete cascade,
  token text not null,
  updated_at timestamptz default now()
);
alter table device_tokens enable row level security;
create policy "own token" on device_tokens for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- FOLLOWS -------------------------------------------------------------
create table follows (
  follower_id uuid references profiles on delete cascade,
  following_id uuid references profiles on delete cascade,
  created_at timestamptz default now(),
  primary key (follower_id, following_id),
  check (follower_id <> following_id)
);
alter table follows enable row level security;
create policy "follows readable" on follows for select using (true);
create policy "follow" on follows for insert with check (follower_id = auth.uid());
create policy "unfollow" on follows for delete using (follower_id = auth.uid());

create view profile_stats as
select p.id,
  (select count(*) from follows where following_id = p.id)::int as followers,
  (select count(*) from follows where follower_id = p.id)::int as following
from profiles p;
grant select on profile_stats to authenticated;

-- POSTS / REELS -------------------------------------------------------
create table posts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references profiles on delete cascade,
  type text not null check (type in ('text','image','reel')),
  body text,
  media_url text,
  like_count int not null default 0,
  comment_count int not null default 0,
  share_count int not null default 0,
  created_at timestamptz default now()
);
create index on posts (created_at desc);
create index on posts (author_id, created_at desc);
alter table posts enable row level security;
create policy "posts readable" on posts for select using (true);
create policy "create own post" on posts for insert with check (author_id = auth.uid());
create policy "delete own post" on posts for delete using (author_id = auth.uid());

create table post_likes (
  post_id uuid references posts on delete cascade,
  user_id uuid references profiles on delete cascade,
  primary key (post_id, user_id)
);
alter table post_likes enable row level security;
create policy "likes readable" on post_likes for select using (true);
create policy "like" on post_likes for insert with check (user_id = auth.uid());
create policy "unlike" on post_likes for delete using (user_id = auth.uid());

create table comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references posts on delete cascade,
  author_id uuid not null references profiles on delete cascade,
  body text not null check (length(body) between 1 and 1000),
  created_at timestamptz default now()
);
create index on comments (post_id, created_at);
alter table comments enable row level security;
create policy "comments readable" on comments for select using (true);
create policy "comment" on comments for insert with check (author_id = auth.uid());
create policy "delete own comment" on comments for delete using (author_id = auth.uid());

-- FREE USERS: max 5 posts per 24h (premium = unlimited) ---------------
create function limit_posts() returns trigger language plpgsql security definer set search_path = public as $$
declare v_plan text; v_exp timestamptz; v_cnt int;
begin
  select plan, premium_expires_at into v_plan, v_exp from profiles where id = new.author_id;
  if v_plan = 'free' or v_exp is null or v_exp < now() then
    select count(*) into v_cnt from posts
      where author_id = new.author_id and created_at > now() - interval '24 hours';
    if v_cnt >= 5 then
      raise exception 'FREE_LIMIT: Free users can post 5 times per day. Get Premium for unlimited posts.';
    end if;
  end if;
  return new;
end $$;
create trigger t_limit_posts before insert on posts for each row execute function limit_posts();

-- CHAT ----------------------------------------------------------------
create table chats (
  id uuid primary key default gen_random_uuid(),
  user_a uuid not null references profiles on delete cascade,
  user_b uuid not null references profiles on delete cascade,
  last_message text,
  updated_at timestamptz default now(),
  unique (user_a, user_b),
  check (user_a < user_b)
);
alter table chats enable row level security;
create policy "chat members read" on chats for select using (auth.uid() in (user_a, user_b));
create policy "chat members create" on chats for insert with check (auth.uid() in (user_a, user_b));

create table messages (
  id uuid primary key default gen_random_uuid(),
  chat_id uuid not null references chats on delete cascade,
  sender_id uuid not null references profiles on delete cascade,
  type text not null check (type in ('text','image','voice')),
  body text,
  media_url text,
  duration_ms int,
  created_at timestamptz default now()
);
create index on messages (chat_id, created_at desc);
alter table messages enable row level security;
create policy "chat members read msgs" on messages for select using (
  exists (select 1 from chats c where c.id = chat_id and auth.uid() in (c.user_a, c.user_b)));
create policy "chat members send msgs" on messages for insert with check (
  sender_id = auth.uid() and
  exists (select 1 from chats c where c.id = chat_id and auth.uid() in (c.user_a, c.user_b)));

-- CALLS ---------------------------------------------------------------
create table calls (
  id uuid primary key default gen_random_uuid(),
  caller_id uuid not null references profiles,
  callee_id uuid not null references profiles,
  channel text not null,
  kind text not null check (kind in ('audio','video')),
  status text not null default 'ringing' check (status in ('ringing','accepted','rejected','missed','ended')),
  created_at timestamptz default now()
);
alter table calls enable row level security;
create policy "call members read" on calls for select using (auth.uid() in (caller_id, callee_id));
create policy "caller creates" on calls for insert with check (caller_id = auth.uid());
create policy "call members update" on calls for update using (auth.uid() in (caller_id, callee_id));
revoke update on calls from authenticated;
grant update (status) on calls to authenticated;

-- NOTIFICATIONS -------------------------------------------------------
create table notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles on delete cascade,   -- recipient
  actor_id uuid references profiles on delete cascade,
  type text not null check (type in ('like','comment','follow','message','premium')),
  post_id uuid references posts on delete cascade,
  body text,
  is_read boolean not null default false,
  created_at timestamptz default now()
);
create index on notifications (user_id, created_at desc);
alter table notifications enable row level security;
create policy "own notifications" on notifications for select using (user_id = auth.uid());
create policy "mark read" on notifications for update using (user_id = auth.uid());
create policy "delete own notifications" on notifications for delete using (user_id = auth.uid());
revoke update on notifications from authenticated;
grant update (is_read) on notifications to authenticated;

-- TRIGGERS: counters + notifications ---------------------------------
create function on_like() returns trigger language plpgsql security definer set search_path = public as $$
declare v_author uuid;
begin
  if tg_op = 'INSERT' then
    update posts set like_count = like_count + 1 where id = new.post_id returning author_id into v_author;
    if v_author is not null and v_author <> new.user_id then
      insert into notifications (user_id, actor_id, type, post_id) values (v_author, new.user_id, 'like', new.post_id);
    end if;
  else
    update posts set like_count = greatest(like_count - 1, 0) where id = old.post_id;
  end if;
  return null;
end $$;
create trigger t_like after insert or delete on post_likes for each row execute function on_like();

create function on_comment() returns trigger language plpgsql security definer set search_path = public as $$
declare v_author uuid;
begin
  if tg_op = 'INSERT' then
    update posts set comment_count = comment_count + 1 where id = new.post_id returning author_id into v_author;
    if v_author is not null and v_author <> new.author_id then
      insert into notifications (user_id, actor_id, type, post_id, body)
      values (v_author, new.author_id, 'comment', new.post_id, left(new.body, 80));
    end if;
  else
    update posts set comment_count = greatest(comment_count - 1, 0) where id = old.post_id;
  end if;
  return null;
end $$;
create trigger t_comment after insert or delete on comments for each row execute function on_comment();

create function on_follow() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into notifications (user_id, actor_id, type) values (new.following_id, new.follower_id, 'follow');
  return null;
end $$;
create trigger t_follow after insert on follows for each row execute function on_follow();

create function on_message() returns trigger language plpgsql security definer set search_path = public as $$
declare v_to uuid; v_preview text;
begin
  v_preview := case new.type when 'image' then '📷 Photo' when 'voice' then '🎤 Voice message' else left(new.body, 100) end;
  update chats set last_message = v_preview, updated_at = now() where id = new.chat_id
    returning case when user_a = new.sender_id then user_b else user_a end into v_to;
  if v_to is not null then
    insert into notifications (user_id, actor_id, type, body) values (v_to, new.sender_id, 'message', v_preview);
  end if;
  return null;
end $$;
create trigger t_message after insert on messages for each row execute function on_message();

create function bump_share(p_post uuid) returns void language sql security definer set search_path = public as $$
  update posts set share_count = share_count + 1 where id = p_post;
$$;
grant execute on function bump_share(uuid) to authenticated;

-- REDEEM CODES ----------------------------------------------------------
create table redeem_codes (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,                 -- stored UPPERCASE
  plan text not null check (plan in ('student','pro','promax')),
  duration_days int not null,
  is_used boolean not null default false,
  used_by uuid references profiles,
  used_at timestamptz,
  created_by uuid references profiles,
  created_at timestamptz default now()
);
alter table redeem_codes enable row level security;
-- only admins can read the list; nobody can write directly
create policy "admin reads codes" on redeem_codes for select using (
  exists (select 1 from profiles where id = auth.uid() and is_admin));

create table redeem_attempts (
  user_id uuid, success boolean, created_at timestamptz default now()
);
alter table redeem_attempts enable row level security;

-- Atomic redeem: validate -> upgrade -> deactivate, in one transaction.
create or replace function redeem_code(p_code text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_row redeem_codes%rowtype;
  v_exp timestamptz;
begin
  if v_uid is null then raise exception 'not authenticated'; end if;

  if (select count(*) from redeem_attempts
       where user_id = v_uid and success = false and created_at > now() - interval '1 hour') >= 5 then
    return jsonb_build_object('ok', false, 'error', 'too_many_attempts');
  end if;

  select * into v_row from redeem_codes
   where code = upper(trim(p_code)) and is_used = false
   for update;                                   -- row lock: no double redeem

  if not found then
    insert into redeem_attempts values (v_uid, false);
    return jsonb_build_object('ok', false, 'error', 'invalid_or_used');
  end if;

  v_exp := greatest(coalesce((select premium_expires_at from profiles where id = v_uid), now()), now())
           + make_interval(days => v_row.duration_days);

  update profiles set is_verified = true,
         badge = case when v_row.plan = 'promax' then 'gold' else 'blue' end,
         plan = v_row.plan,
         premium_expires_at = v_exp
   where id = v_uid;

  update redeem_codes set is_used = true, used_by = v_uid, used_at = now() where id = v_row.id;
  insert into redeem_attempts values (v_uid, true);
  insert into notifications (user_id, type, body) values (v_uid, 'premium', v_row.plan);

  return jsonb_build_object('ok', true, 'plan', v_row.plan, 'expires_at', v_exp);
end $$;
grant execute on function redeem_code(text) to authenticated;

-- Admin: generate codes like VIBEX-PRO-A1B2C3
create or replace function generate_codes(p_plan text, p_count int) returns setof text
language plpgsql security definer set search_path = public as $$
declare v_days int; v_prefix text; i int; v_code text;
begin
  if not exists (select 1 from profiles where id = auth.uid() and is_admin) then
    raise exception 'admin only';
  end if;
  if p_count < 1 or p_count > 50 then raise exception 'count must be 1-50'; end if;
  v_days   := case p_plan when 'promax' then 365 else 30 end;
  v_prefix := case p_plan when 'student' then 'VIBEX-STU' when 'pro' then 'VIBEX-PRO' else 'VIBEX-MAX' end;
  for i in 1..p_count loop
    v_code := v_prefix || '-' || upper(substr(md5(random()::text || clock_timestamp()::text), 1, 6));
    insert into redeem_codes (code, plan, duration_days, created_by) values (v_code, p_plan, v_days, auth.uid());
    return next v_code;
  end loop;
end $$;
grant execute on function generate_codes(text, int) to authenticated;

-- Admin: grant / revoke premium manually
create or replace function admin_set_plan(p_username text, p_plan text, p_days int) returns void
language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  if not exists (select 1 from profiles where id = auth.uid() and is_admin) then
    raise exception 'admin only';
  end if;
  select id into v_id from profiles where username = lower(trim(p_username));
  if v_id is null then raise exception 'user not found'; end if;
  update profiles set
    plan = p_plan,
    is_verified = (p_plan <> 'free'),
    badge = case p_plan when 'free' then 'none' when 'promax' then 'gold' else 'blue' end,
    premium_expires_at = case when p_plan = 'free' then null else now() + make_interval(days => p_days) end
  where id = v_id;
  if p_plan <> 'free' then
    insert into notifications (user_id, type, body) values (v_id, 'premium', p_plan);
  end if;
end $$;
grant execute on function admin_set_plan(text, text, int) to authenticated;

-- Daily expiry (enable pg_cron: Database > Extensions)
create or replace function expire_premiums() returns void language sql security definer set search_path = public as $$
  update profiles set is_verified = false, badge = 'none', plan = 'free'
   where plan <> 'free' and premium_expires_at < now();
$$;
-- select cron.schedule('expire-premium', '5 0 * * *', 'select expire_premiums()');

-- REALTIME ------------------------------------------------------------
alter publication supabase_realtime add table messages, calls, notifications, chats;

-- STORAGE -------------------------------------------------------------
insert into storage.buckets (id, name, public) values
  ('avatars','avatars',true), ('covers','covers',true), ('posts','posts',true),
  ('reels','reels',true), ('chat-media','chat-media',true)
on conflict do nothing;

create policy "public read media" on storage.objects for select
  using (bucket_id in ('avatars','covers','posts','reels','chat-media'));
create policy "upload to own folder" on storage.objects for insert to authenticated
  with check (bucket_id in ('avatars','covers','posts','reels') and (storage.foldername(name))[1] = auth.uid()::text);
create policy "chat media upload" on storage.objects for insert to authenticated
  with check (bucket_id = 'chat-media');
create policy "delete own media" on storage.objects for delete to authenticated
  using ((storage.foldername(name))[1] = auth.uid()::text);

-- =====================================================================
-- TEST REDEEM CODE (you asked for 1216): one-time, Pro plan, 30 days.
-- DELETE IT BEFORE LAUNCH - a 4-digit code is easy to guess.
insert into redeem_codes (code, plan, duration_days) values ('1216', 'pro', 30);

-- MAKE YOURSELF ADMIN (after you sign up in the app), replace the email:
-- update profiles set is_admin = true where id = (select id from auth.users where email = 'you@example.com');
-- =====================================================================
